Someone said it worked.  So, I think this works?
