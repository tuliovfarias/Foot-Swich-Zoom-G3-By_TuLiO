This has been tested and works.  There are some shortcomings. 

(1) The caps are too big and don't conveniently fit into the USB port.

(2) It's about 2 mil too wide.

