**Standalone version of the Zoom B3/G3 controller.** 

Info on standalone version: https://github.com/Craven112/ZoomControl/wiki/Standalone-Version

General info: https://github.com/Craven112/ZoomControl/wiki

Video demonstrations: https://github.com/Craven112/ZoomControl/wiki/Videos

Contact: cdeenen@outlook.com

***

# To do

* Clean up code
* Tuner button sometimes not registered properly by Zoom
* Takes long before Zoom accepts program changes at startup. Why?
* More thorough error/stability checking

***

# Changelog

29-06-2015	v0.1.1
* First release
